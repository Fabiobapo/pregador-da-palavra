# Pregador da Palavra (fase 1: base)

Esta fase entrega: estrutura do projeto, banco PostgreSQL (Docker), schema Prisma com igrejas e papéis,
cadastro/login, sessão segura, proteção CSRF por verificação de origem, limite de tentativas, PWA básico e tema claro/escuro.

**Ainda não implementado:** recuperação de senha, convites, Bíblia, sermões, IA, imagens, Holyrics, exportações.
**Ícones do PWA:** adicione `icon-192.png` e `icon-512.png` em `public/` e liste-os em `src/app/manifest.ts`.
**Não testado em execução:** o código foi escrito sem acesso à internet para instalar dependências; rode os passos abaixo e relate qualquer erro.

## Instalação
1. Instale Node.js 20+ e Docker.
2. `cp .env.example .env` e troque o `SESSION_SECRET` (`openssl rand -base64 48`).
3. `docker compose up -d`
4. `npm install`
5. `npx prisma migrate dev --name init`
6. `npm run db:seed` (cria `demo@pregador.local` / `Demo@12345`; use só em desenvolvimento)
7. `npm run dev` e abra http://localhost:3000
8. `npm test` roda os testes de validação.

## Notas de segurança desta fase
- Senhas com bcrypt (custo 12). Cookie `httpOnly`, `SameSite=Lax`, `Secure` em produção.
- O limitador de tentativas é em memória: serve para uma instância. Para produção, use Redis.
- Todo modelo futuro deve incluir `churchId` e filtrar por ele para isolar os dados de cada igreja.
