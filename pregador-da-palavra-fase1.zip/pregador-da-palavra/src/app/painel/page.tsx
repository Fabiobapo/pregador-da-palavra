import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import { readSession } from "@/lib/session";
import ThemeToggle from "@/components/ThemeToggle";
import LogoutButton from "./LogoutButton";

export default async function Painel() {
  const s = await readSession();
  if (!s) redirect("/entrar");
  const user = await db.user.findUnique({
    where: { id: s.uid },
    include: { memberships: { include: { church: true } } },
  });
  if (!user) redirect("/entrar");
  const m = user.memberships[0];
  return (
    <main className="mx-auto max-w-3xl p-6">
      <h1 className="font-serif text-3xl">Olá, {user.name}</h1>
      <p className="mt-1">{m?.church.name} · {m?.role}</p>
      <p className="mt-6">A biblioteca de sermões e a Bíblia chegam nas próximas fases.</p>
      <div className="mt-6 flex gap-2"><ThemeToggle /><LogoutButton /></div>
    </main>
  );
}
