import { NextRequest, NextResponse } from "next/server";
import { jwtVerify } from "jose";

// 1) Proteção CSRF: requisições que alteram dados só valem se vierem da mesma origem.
// 2) /painel exige sessão válida.
export async function middleware(req: NextRequest) {
  if (!["GET", "HEAD", "OPTIONS"].includes(req.method)) {
    const origin = req.headers.get("origin");
    if (!origin || new URL(origin).host !== req.nextUrl.host) {
      return NextResponse.json({ error: "Origem não permitida." }, { status: 403 });
    }
  }
  if (req.nextUrl.pathname.startsWith("/painel")) {
    const token = req.cookies.get("pdp_session")?.value;
    try {
      await jwtVerify(token ?? "", new TextEncoder().encode(process.env.SESSION_SECRET!));
    } catch {
      return NextResponse.redirect(new URL("/entrar", req.url));
    }
  }
  return NextResponse.next();
}
export const config = { matcher: ["/painel/:path*", "/api/:path*"] };
